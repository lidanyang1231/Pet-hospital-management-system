/*
 Navicat Premium Data Transfer

 Source Server         : lh
 Source Server Type    : MySQL
 Source Server Version : 50730
 Source Host           : localhost:3306
 Source Schema         : phms

 Target Server Type    : MySQL
 Target Server Version : 50730
 File Encoding         : 65001

 Date: 12/12/2021 14:06:03
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for appointment
-- ----------------------------
DROP TABLE IF EXISTS `appointment`;
CREATE TABLE `appointment`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `pet_id` bigint(20) NULL DEFAULT NULL,
  `user_id` bigint(20) NULL DEFAULT NULL,
  `doctor_id` bigint(20) NULL DEFAULT NULL,
  `app_time` datetime NULL DEFAULT NULL,
  `info` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `create_time` datetime NULL DEFAULT NULL,
  `status` int(5) NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 39 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of appointment
-- ----------------------------
INSERT INTO `appointment` VALUES (1, 1, 1, 1, '2020-04-23 20:33:08', 'aaaaa', '2023-04-23 20:33:11', 4, NULL, NULL);
INSERT INTO `appointment` VALUES (2, 1, 1, 1, '2020-04-25 00:00:00', 'bbbbb', '2023-04-25 20:20:25', 4, '01059000001', 'xxxx');
INSERT INTO `appointment` VALUES (3, 2, 1, 5, '2020-04-25 21:23:56', 'ccccc', '2023-04-25 21:23:59', 4, '01059000002', 'xxxx');
INSERT INTO `appointment` VALUES (4, 3, 6, 5, '2020-04-03 00:00:00', 'ddddd', '2023-04-25 22:51:43', 2, '01059000003', 'xxxx');
INSERT INTO `appointment` VALUES (6, 3, 6, 9, '2020-04-25 00:00:00', 'eeeee', '2023-04-25 22:58:15', 4, '01059000004', 'xxxx');
INSERT INTO `appointment` VALUES (7, 3, 6, 9, '2020-04-25 00:00:00', 'fffff', '2023-04-25 23:03:26', 4, '01059000005', 'xxxx');

-- ----------------------------
-- Table structure for diagnosis
-- ----------------------------
DROP TABLE IF EXISTS `diagnosis`;
CREATE TABLE `diagnosis`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `pet_id` bigint(20) NULL DEFAULT NULL,
  `user_id` bigint(20) NULL DEFAULT NULL,
  `doctor_id` bigint(20) NULL DEFAULT NULL,
  `info` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `type` int(5) NULL DEFAULT NULL,
  `status` int(5) NULL DEFAULT NULL,
  `create_time` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 21 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of diagnosis
-- ----------------------------
INSERT INTO `diagnosis` VALUES (15, 19, 25, 26, 'Vaccination', 2, 1, '2023-04-29 11:27:19');
INSERT INTO `diagnosis` VALUES (17, 20, 1, 1, 'see a doctor', 1, 1, '2023-05-01 13:37:02');
INSERT INTO `diagnosis` VALUES (18, 27, 25, 26, 'cold', 3, 1, '2023-05-21 17:07:43');
INSERT INTO `diagnosis` VALUES (19, 28, 25, 26, 'treat', 2, 1, '2023-05-21 19:12:05');

-- ----------------------------
-- Table structure for notice
-- ----------------------------
DROP TABLE IF EXISTS `notice`;
CREATE TABLE `notice`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `content` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `view_count` bigint(20) NULL DEFAULT NULL,
  `create_time` datetime NULL DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of notice
-- ----------------------------
INSERT INTO `notice` VALUES (2, '<p>pet vaccination</p>\n\n<p>Precautions for pet vaccination</p>', 4, '2023-04-25 22:10:52', 'How often should pet vaccinations be given');
INSERT INTO `notice` VALUES (4, '<p>xxxxx</p>', 2, '2023-04-26 19:15:57', 'xxxxxxx');
INSERT INTO `notice` VALUES (5, '<p>how to keep pets</p>', 1, '2023-04-26 19:46:22', 'What is important about having a dog?');

-- ----------------------------
-- Table structure for page
-- ----------------------------
DROP TABLE IF EXISTS `page`;
CREATE TABLE `page`  (
  `page_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'auto increment primary key',
  `parent_id` int(11) NULL DEFAULT NULL COMMENT 'parent page id',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'page name',
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'page address',
  `level_type` int(11) NULL DEFAULT NULL COMMENT 'page hierarchy',
  `level_index` int(11) NULL DEFAULT NULL COMMENT 'page index',
  `delete_flag` int(1) UNSIGNED ZEROFILL NOT NULL DEFAULT 0 COMMENT 'delete or not',
  `desc` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'describe',
  PRIMARY KEY (`page_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 39 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = COMPACT;

-- ----------------------------
-- Records of page
-- ----------------------------
INSERT INTO `page` VALUES (1, 0, 'system settings', NULL, 0, 10, 0, 'manager');
INSERT INTO `page` VALUES (2, 1, 'User Management', '/admin/userPage', 1, 22, 0, 'manager');
INSERT INTO `page` VALUES (3, 1, 'page management', '/admin/page', 1, 23, 0, 'manager');
INSERT INTO `page` VALUES (4, 1, 'role management', '/admin/role', 1, 24, 0, 'manager');
INSERT INTO `page` VALUES (6, 0, 'pet management', '', 0, 1, 0, 'left_menu_shop');
INSERT INTO `page` VALUES (7, 6, 'pet list', '/user/pet/petList', 1, 1, 0, '');
INSERT INTO `page` VALUES (8, 6, 'Health History', '/user/diagnosis/diagnosisList', 1, 2, 0, '');
INSERT INTO `page` VALUES (9, 0, 'appointment management', '', 0, 2, 0, 'left_menu_data');
INSERT INTO `page` VALUES (10, 9, 'appointment list', '/user/apply/applyList', 1, 1, 0, '');
INSERT INTO `page` VALUES (12, 0, 'daily health', '', 0, 3, 0, 'user');
INSERT INTO `page` VALUES (13, 12, 'health guide', '/user/notice/list', 1, 1, 0, '');
INSERT INTO `page` VALUES (14, 12, 'monitoring', '/health/assess', 1, 2, 0, '');
INSERT INTO `page` VALUES (19, 0, 'pet file', '', 0, 4, 0, 'left_menu_house');
INSERT INTO `page` VALUES (20, 19, 'number of reservations', '/health/tjApply', 1, 1, 0, '');
INSERT INTO `page` VALUES (21, 0, 'hospital management', '', 0, 5, 0, 'page');
INSERT INTO `page` VALUES (23, 21, 'number of reservations ', '/health/tjApplyDoctor', 1, 2, 0, '');
INSERT INTO `page` VALUES (24, 21, 'Guidelines', '/user/notice/publish', 1, 3, 0, '');
INSERT INTO `page` VALUES (27, 19, 'pet log', '/user/petDaily/petDailyList', 1, 2, 0, '');
INSERT INTO `page` VALUES (28, 19, 'Guidelines', '/health/tjApply', 1, 3, 0, NULL);
INSERT INTO `page` VALUES (30, 6, 'Health History', '/user/diagnosis/diagnosisListDoctor', 1, 3, 0, '');
INSERT INTO `page` VALUES (31, 9, 'Appointment list-', '/user/apply/applyListDoctor', 1, 3, 0, NULL);
INSERT INTO `page` VALUES (32, 21, 'Standard setting', '/user/standard/standardListDoctor', 1, 4, 0, NULL);
INSERT INTO `page` VALUES (33, 12, 'health standard', '/user/standard/standardList', 1, 3, 0, NULL);
INSERT INTO `page` VALUES (34, 19, 'Pet Log -', '/user/petDaily/petDailyListDoctor', 1, 4, 0, NULL);
INSERT INTO `page` VALUES (35, 19, 'log chart', '/health/tjDaily', 1, 5, 0, NULL);
INSERT INTO `page` VALUES (36, 21, 'pet log', '/health/tjDailyDoctor', 1, 5, 0, NULL);
INSERT INTO `page` VALUES (37, 9, 'doctor time', '/health/freeTime', 1, 4, 0, NULL);
INSERT INTO `page` VALUES (38, 21, 'guide list', '/user/notice/listDoctor', 1, 6, 0, '');

-- ----------------------------
-- Table structure for pet
-- ----------------------------
DROP TABLE IF EXISTS `pet`;
CREATE TABLE `pet`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `weight` double(10, 2) NULL DEFAULT NULL,
  `height` double(10, 2) NULL DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `birthday` datetime NULL DEFAULT NULL,
  `img` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `create_time` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 32 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of pet
-- ----------------------------
INSERT INTO `pet` VALUES (3, 6, 'cat', 11.00, 12.00, '1', '2023-04-25 00:00:00', NULL, '2023-04-25 22:51:21');
INSERT INTO `pet` VALUES (4, 6, 'dog', 20.00, 30.00, '2', '2023-04-30 00:00:00', NULL, '2023-04-25 23:05:12');
INSERT INTO `pet` VALUES (5, 11, 'pig', 20.00, 40.00, '2', '2023-04-30 00:00:00', NULL, '2023-04-26 06:58:26');
INSERT INTO `pet` VALUES (7, 13, 'cow', 20.00, 30.00, '2', '2022-12-31 00:00:00', NULL, '2023-04-26 08:38:53');
INSERT INTO `pet` VALUES (8, 17, 'sheep', 20.00, 40.00, '2', '2023-05-26 13:56:18', NULL, '2023-04-26 13:56:32');

-- ----------------------------
-- Table structure for pet_daily
-- ----------------------------
DROP TABLE IF EXISTS `pet_daily`;
CREATE TABLE `pet_daily`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `pet_id` bigint(20) NULL DEFAULT NULL,
  `user_id` bigint(20) NULL DEFAULT NULL,
  `temperature` double(10, 2) NULL DEFAULT NULL,
  `weight` double(10, 2) NULL DEFAULT NULL,
  `height` double(10, 2) NULL DEFAULT NULL,
  `appetite` double(10, 2) NULL DEFAULT NULL,
  `status` int(5) NULL DEFAULT NULL,
  `create_time` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 28 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of pet_daily
-- ----------------------------
INSERT INTO `pet_daily` VALUES (2, 3, 11, 12.00, 40.00, 30.00, 11.00, 1, '2023-04-26 07:03:16');
INSERT INTO `pet_daily` VALUES (3, 4, 6, 12.00, 20.00, 15.00, 11.00, 1, '2023-04-26 07:10:35');
INSERT INTO `pet_daily` VALUES (4, 4, 6, 12.00, 10.00, 10.00, 11.00, 1, '2023-04-26 07:17:13');
INSERT INTO `pet_daily` VALUES (5, 4, 1, 12.00, 10.00, 10.00, 11.00, 1, '2023-04-26 07:36:22');
INSERT INTO `pet_daily` VALUES (6, 4, 13, 12.00, 6.00, 6.00, 11.00, 1, '2023-04-26 08:33:13');


-- ----------------------------
-- Table structure for role
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role`  (
  `role_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'auto increment primary key',
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'type name',
  `desc` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'describe',
  PRIMARY KEY (`role_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = COMPACT;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES (1, 'super administrator', 'super administrator');
INSERT INTO `role` VALUES (2, 'general user', 'general user');
INSERT INTO `role` VALUES (3, 'doctor', 'doctor');

-- ----------------------------
-- Table structure for role_page
-- ----------------------------
DROP TABLE IF EXISTS `role_page`;
CREATE TABLE `role_page`  (
  `rp_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'primary key auto increment',
  `role_id` int(11) NULL DEFAULT NULL COMMENT 'role id',
  `page_id` int(11) NULL DEFAULT NULL COMMENT 'page id',
  PRIMARY KEY (`rp_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 889 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = COMPACT;

-- ----------------------------
-- Records of role_page
-- ----------------------------
INSERT INTO `role_page` VALUES (1, 1, 1);
INSERT INTO `role_page` VALUES (2, 1, 2);
INSERT INTO `role_page` VALUES (3, 1, 3);
INSERT INTO `role_page` VALUES (4, 1, 4);
INSERT INTO `role_page` VALUES (803, 2, 6);
INSERT INTO `role_page` VALUES (804, 2, 7);
INSERT INTO `role_page` VALUES (805, 2, 8);
INSERT INTO `role_page` VALUES (806, 2, 9);
INSERT INTO `role_page` VALUES (807, 2, 10);
INSERT INTO `role_page` VALUES (808, 2, 37);
INSERT INTO `role_page` VALUES (809, 2, 12);
INSERT INTO `role_page` VALUES (810, 2, 13);
INSERT INTO `role_page` VALUES (811, 2, 14);
INSERT INTO `role_page` VALUES (812, 2, 33);
INSERT INTO `role_page` VALUES (813, 2, 19);
INSERT INTO `role_page` VALUES (814, 2, 27);
INSERT INTO `role_page` VALUES (815, 2, 28);
INSERT INTO `role_page` VALUES (816, 2, 35);
INSERT INTO `role_page` VALUES (852, 3, 6);
INSERT INTO `role_page` VALUES (853, 3, 30);
INSERT INTO `role_page` VALUES (854, 3, 9);
INSERT INTO `role_page` VALUES (855, 3, 31);
INSERT INTO `role_page` VALUES (856, 3, 37);
INSERT INTO `role_page` VALUES (857, 3, 19);
INSERT INTO `role_page` VALUES (858, 3, 34);
INSERT INTO `role_page` VALUES (859, 3, 21);
INSERT INTO `role_page` VALUES (860, 3, 23);
INSERT INTO `role_page` VALUES (861, 3, 24);
INSERT INTO `role_page` VALUES (862, 3, 32);
INSERT INTO `role_page` VALUES (863, 3, 36);
INSERT INTO `role_page` VALUES (864, 3, 38);
INSERT INTO `role_page` VALUES (865, 1, 6);
INSERT INTO `role_page` VALUES (866, 1, 7);
INSERT INTO `role_page` VALUES (867, 1, 8);
INSERT INTO `role_page` VALUES (868, 1, 30);
INSERT INTO `role_page` VALUES (869, 1, 9);
INSERT INTO `role_page` VALUES (870, 1, 10);
INSERT INTO `role_page` VALUES (871, 1, 31);
INSERT INTO `role_page` VALUES (872, 1, 37);
INSERT INTO `role_page` VALUES (873, 1, 12);
INSERT INTO `role_page` VALUES (874, 1, 13);
INSERT INTO `role_page` VALUES (875, 1, 14);
INSERT INTO `role_page` VALUES (876, 1, 33);
INSERT INTO `role_page` VALUES (877, 1, 19);
INSERT INTO `role_page` VALUES (878, 1, 20);
INSERT INTO `role_page` VALUES (879, 1, 27);
INSERT INTO `role_page` VALUES (880, 1, 28);
INSERT INTO `role_page` VALUES (881, 1, 34);
INSERT INTO `role_page` VALUES (882, 1, 35);
INSERT INTO `role_page` VALUES (883, 1, 21);
INSERT INTO `role_page` VALUES (884, 1, 23);
INSERT INTO `role_page` VALUES (885, 1, 24);
INSERT INTO `role_page` VALUES (886, 1, 32);
INSERT INTO `role_page` VALUES (887, 1, 36);
INSERT INTO `role_page` VALUES (888, 1, 38);

-- ----------------------------
-- Table structure for standard
-- ----------------------------
DROP TABLE IF EXISTS `standard`;
CREATE TABLE `standard`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `age_min` int(10) NULL DEFAULT NULL,
  `age_max` int(10) NULL DEFAULT NULL,
  `temp_min` double(10, 2) NULL DEFAULT NULL,
  `temp_max` double(10, 2) NULL DEFAULT NULL,
  `weight_min` double(10, 2) NULL DEFAULT NULL,
  `weight_max` double(10, 2) NULL DEFAULT NULL,
  `height_min` double(10, 2) NULL DEFAULT NULL,
  `height_max` double(10, 2) NULL DEFAULT NULL,
  `appetite_min` double(10, 2) NULL DEFAULT NULL,
  `appetite_max` double(10, 2) NULL DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `status` int(5) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of standard
-- ----------------------------
INSERT INTO `standard` VALUES (2, 1, 10, 30.00, 50.00, 10.00, 50.00, 5.00, 70.00, 10.00, 40.00, '1', 1);
INSERT INTO `standard` VALUES (3, 5, 20, 15.00, 40.00, 10.00, 50.00, 12.00, 70.00, 10.00, 30.00, '2', 1);
INSERT INTO `standard` VALUES (4, 1, 10, 10.00, 10.00, 20.00, 30.00, 40.00, 50.00, 10.00, 10.00, '2', 1);

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `age` int(11) NULL DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `id_card` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `id_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `qualification` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `hospital_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `hospital_address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `department` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `info` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `img` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `create_time` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 42 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, NULL, 'admin', 'e10adc3949ba59abbe56e057f20f883e', '555@qq.com', '222222222222222222', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '01059901115', '222', NULL);
INSERT INTO `user` VALUES (25, NULL, 'user', 'e10adc3949ba59abbe56e057f20f883e', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '01059901111', 'Daegu', '2023-04-29 11:13:18');
INSERT INTO `user` VALUES (26, NULL, 'doctor1', 'e10adc3949ba59abbe56e057f20f883e', '', '1234', NULL, NULL, 'Hospital', 'Daegu', 'doctor', NULL, NULL, '01059901112', NULL, '2023-04-29 11:21:43');
INSERT INTO `user` VALUES (30, NULL, 'doctor2', 'e10adc3949ba59abbe56e057f20f883e', '', '2234', NULL, NULL, 'Hospital', 'Daegu', 'doctor', NULL, NULL, '01059901113', NULL, '2023-04-29 11:26:06');
INSERT INTO `user` VALUES (31, NULL, 'doctor3', 'e10adc3949ba59abbe56e057f20f883e', '', '135489654123698741', NULL, NULL, 'Hospital', 'Daegu', 'doctor', NULL, NULL, '01059901114', NULL, '2023-05-01 14:33:17');

-- ----------------------------
-- Table structure for user_role
-- ----------------------------
DROP TABLE IF EXISTS `user_role`;
CREATE TABLE `user_role`  (
  `ur_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'auto increment primary key',
  `user_id` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'user id',
  `role_id` int(11) NULL DEFAULT NULL COMMENT 'role id',
  PRIMARY KEY (`ur_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 184 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = COMPACT;

-- ----------------------------
-- Records of user_role
-- ----------------------------
INSERT INTO `user_role` VALUES (1, '1', 1);
INSERT INTO `user_role` VALUES (170, '25', 2);
INSERT INTO `user_role` VALUES (171, '26', 3);
INSERT INTO `user_role` VALUES (172, '30', 3);
INSERT INTO `user_role` VALUES (173, '31', 3);
INSERT INTO `user_role` VALUES (179, '37', 2);
INSERT INTO `user_role` VALUES (180, '38', 2);
INSERT INTO `user_role` VALUES (181, '39', 2);

SET FOREIGN_KEY_CHECKS = 1;
