package com.phms.utils;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Properties;


public class PropertyUtil {


	private final static String CONFIGURE_LOCATION = "config.properties";

	private final static Properties property = new Properties();


	public static String getConfigureProperties(String propertyName) {
		try {
			InputStreamReader in = new InputStreamReader(
					PropertyUtil.class.getClassLoader().getResourceAsStream(CONFIGURE_LOCATION), "UTF-8");
			property.load(in);
			String result = property.getProperty(propertyName);
			if (null != result && !"".equalsIgnoreCase(result)) {
				return result.trim();
			} else {
				return null;
			}
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

}