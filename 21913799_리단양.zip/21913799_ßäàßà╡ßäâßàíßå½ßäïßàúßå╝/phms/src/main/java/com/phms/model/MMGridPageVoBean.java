package com.phms.model;

import java.io.Serializable;
import java.util.List;


public class MMGridPageVoBean<T> implements Serializable {

	private static final long serialVersionUID = 5033466102339979707L;
	private long total;
	private List<T> rows;
	private Object other;

	public List<T> getRows() {
		return rows;
	}

	public void setRows(List<T> rows) {
		this.rows = rows;
	}

	public Object getOther() {
		return other;
	}

	public void setOther(Object other) {
		this.other = other;
	}

	public long getTotal() {
		return total;
	}

	public void setTotal(long total) {
		this.total = total;
	}
}