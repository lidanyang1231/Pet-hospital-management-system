package com.phms.pojo;

import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

public class Appointment extends BaseBean{

    private Long id;

    private Long petId;


    private Long userId;

    private Long doctorId;


    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date appTime;


    private String info;
    private String phone;
    private String address;
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }


    private Date createTime;


    private Integer status;


    public Long getId() {
        return id;
    }


    public void setId(Long id) {
        this.id = id;
    }


    public Long getPetId() {
        return petId;
    }


    public void setPetId(Long petId) {
        this.petId = petId;
    }

    public Long getUserId() {
        return userId;
    }


    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getDoctorId() {
        return doctorId;
    }


    public void setDoctorId(Long doctorId) {
        this.doctorId = doctorId;
    }


    public Date getAppTime() {
        return appTime;
    }


    public void setAppTime(Date appTime) {
        this.appTime = appTime;
    }


    public String getInfo() {
        return info;
    }


    public void setInfo(String info) {
        this.info = info == null ? null : info.trim();
    }


    public Date getCreateTime() {
        return createTime;
    }


    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }


    public Integer getStatus() {
        return status;
    }


    public void setStatus(Integer status) {
        this.status = status;
    }
}