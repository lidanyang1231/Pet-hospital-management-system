package com.phms.model;

import org.springframework.stereotype.Component;

import java.util.HashMap;


@Component
public class ResultMap extends HashMap<String, Object> {

	private static final long serialVersionUID = 1L;

	public ResultMap() {
	}


	public ResultMap success() {
		this.put("result", "success");
		return this;
	}


	public ResultMap fail() {
		this.put("result", "fail");
		return this;
	}


	public ResultMap message(Object message) {
		this.put("message", message);
		return this;
	}
}