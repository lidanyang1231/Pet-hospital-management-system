package com.phms.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


public class MyUtils {
	public static String START_HOUR = " 00:00:00";
	public static String END_HOUR = " 23:59:59";

	private MyUtils() {
		throw new IllegalStateException("Utility class");
	}


	private static final Logger logger = LoggerFactory.getLogger(MyUtils.class);


	public static boolean isEmail(String email) {
		String regex = "^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$";
		if (email.matches(regex)) {
			return true;
		} else {
			return false;
		}
	}


	public static boolean isPhoneNum(String phoneNume) {
		String pattern = "^((1[3,5,8][0-9])|(14[5,7])|(17[0,6,7,8])|(19[7]))\\d{8}$";
		if (phoneNume.matches(pattern)) {
			return true;
		} else {
			return false;
		}
	}

	public static String getNowDateTime() {
		String dateTime = "";
		String pattern = "yyyy-MM-dd HH:mm:ss";
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		dateTime = sdf.format(date);
		return dateTime;
	}


	public static String getNowDateYMD() {
		String dateTime = "";
		String pattern = "yyyy-MM-dd";
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		dateTime = sdf.format(date);
		return dateTime;
	}


	public static String getNowDateCHYMD() {
		String dateTime = "";
		String pattern = "yyyy年MM月dd日";
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		dateTime = sdf.format(date);
		return dateTime;
	}


	public static synchronized String getAutoNumber() {
		String autoNumber = "";
		int number = 0;
		String oldDate = "";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		String nowDate = sdf.format(new Date());
		File f2 = new File(MyUtils.class.getResource("").getPath());
		String path = f2.getAbsolutePath();

		File f = new File(path + "/date.txt");

		try {
			BufferedReader br = new BufferedReader(new FileReader(f));
			String line = "";
			try {
				line = br.readLine();
				String[] sb = line.split(",");
				oldDate = sb[0];
				if (oldDate.equals(nowDate)) {
					number = Integer.parseInt(sb[1]);
				} else {
					number = 0;
				}
				br.close();
			} catch (IOException e) {
				logger.error("An exception occurred when obtaining the number based on time", e);
			}

			autoNumber += nowDate;
			number++;
			int i = 1;
			int n = number;
			while ((n = n / 10) != 0) {
				i++;
			}
			for (int j = 0; j < 4 - i; j++) {
				autoNumber += "0";
			}
			autoNumber += number;

			try {
				BufferedWriter bw = new BufferedWriter(new FileWriter(f));
				bw.write(nowDate + "," + number);
				bw.close();
			} catch (IOException e) {
				logger.error("An exception occurred when obtaining the number based on time", e);
			}

		} catch (FileNotFoundException e) {
			logger.error("An exception occurred when obtaining the number based on time", e);
		}

		return autoNumber;
	}


	public static int get2DateDay(String startDate, String endDate) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date date1 = null;
		Date date2 = null;
		long days = 0;
		try {
			date1 = sdf.parse(startDate);
			date2 = sdf.parse(endDate);
			days = (date2.getTime() - date1.getTime()) / (24 * 3600 * 1000);

		} catch (ParseException e) {
			logger.error("An exception occurred in obtaining the number of days between two dates", e);
		}

		return (int) days + 1;
	}


	public static String toLowCase(String s) {
		return s.substring(0, 1).toLowerCase() + s.substring(1, s.length());
	}


	public static String setStartUP(String s) {
		return s.substring(0, 1).toUpperCase() + s.substring(1, s.length());
	}


	public static String getUp_ClassName(String s) {
		String cName = "";

		cName = s.substring(1, 2).toUpperCase() + s.substring(2, s.length());

		String[] tem = cName.split("_");
		int len = tem.length;
		cName = tem[0];
		for (int i = 1; i < len; i++) {
			cName += setStartUP(tem[i]);
		}

		return cName;
	}


	public static String getFiled2Pro(String s) {
		String pName = "";
		String[] tem = s.split("_");

		int len = tem.length;
		pName = tem[0];
		for (int i = 1; i < len; i++) {
			pName += setStartUP(tem[i]);
		}
		return pName;
	}



	public static Date getStringDate(String time) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date date = null;
		try {
			date = sdf.parse(time);
		} catch (ParseException e) {
			logger.error("Date conversion error：", e);
		}
		return date;
	}


	public static Date getStringDateTime(String time) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = null;
		try {
			date = sdf.parse(time);
		} catch (ParseException e) {
			logger.error("Date conversion error：", e);
		}
		return date;
	}


	public static String getNowDateFirstDay() {
		Format format = new SimpleDateFormat("yyyy-MM-dd");

		Calendar c = Calendar.getInstance();
		c.add(Calendar.MONTH, 0);
		c.set(Calendar.DAY_OF_MONTH, 1);
		return format.format(c.getTime());
	}


	public static String getNowDateLastDay() {
		Format format = new SimpleDateFormat("yyyy-MM-dd");

		Calendar ca = Calendar.getInstance();
		ca.set(Calendar.DAY_OF_MONTH, ca.getActualMaximum(Calendar.DAY_OF_MONTH));
		return format.format(ca.getTime());
	}
	

	public static String getDate2String(Date date) {
		Format format = new SimpleDateFormat("yyyy year mm month dd day HH minutes ss seconds");
		return format.format(date);
	}


	public static String getDate2String(Date date, String f) {
		Format format = new SimpleDateFormat(f);
		return format.format(date);
	}

}
