package com.phms.shiro;

import com.phms.mapper.UserMapper;
import com.phms.mapper.UserRoleMapper;
import com.phms.pojo.User;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class CustomRealm extends AuthorizingRealm {

	private final UserMapper userMapper;

	private final UserRoleMapper userRoleMapper;

	private final Logger logger = LoggerFactory.getLogger(CustomRealm.class);

	private static Map<String, Session> sessionMap = new HashMap<>();

	@Autowired
	public CustomRealm(UserMapper userMapper, UserRoleMapper userRoleMapper) {
		this.userMapper = userMapper;
		this.userRoleMapper = userRoleMapper;
	}



	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken)
			throws AuthenticationException {

		UsernamePasswordToken token = (UsernamePasswordToken) authenticationToken;

		User user = userMapper.getByName(token.getUsername());
		if (null == user) {
			logger.warn("{}---User does not exist", token.getUsername());

			throw new AccountException("USERNAME_NOT_EXIST");
		}
		String password = user.getPassword();
		if (null == password) {
			logger.warn("{}---User does not exist", token.getUsername());

			throw new AccountException("USERNAME_NOT_EXIST");
		} else if (!password.equals(new String((char[]) token.getCredentials()))) {
			logger.warn("{}---Enter the wrong password", token.getUsername());

			throw new AccountException("PASSWORD_ERR");
		}
		logger.info("{}---Successful identity authentication", user.getName());
		Subject subject = SecurityUtils.getSubject();

		subject.getSession().setTimeout(7_200_000);

		Session s = subject.getSession();
		String uid = user.getId()+"";

		try {
			Session s2 = sessionMap.get(uid);
			if (s2 != null) {
				s2.setTimeout(0);
				sessionMap.remove(s2);
			}
		} catch (Exception e) {

			sessionMap.remove(s);
		}

		sessionMap.put(uid, s);

		return new SimpleAuthenticationInfo(user, password, getName());
	}


	@Override
	protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {

		User user = (User) SecurityUtils.getSubject().getPrincipal();
		SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();

		List<String> roles = null;

		if (null != user) {
			roles = userRoleMapper.getRoles(user.getId()+"");
		} else {
			logger.warn("User session invalid!");
		}
		Set<String> set = new HashSet<>();

		for (String role : roles) {
			set.add(role);
		}

		info.setRoles(set);
		return info;
	}
}