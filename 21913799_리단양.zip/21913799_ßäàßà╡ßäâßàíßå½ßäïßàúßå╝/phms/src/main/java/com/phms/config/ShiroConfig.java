package com.phms.config;

import com.phms.shiro.CustomRealm;
import com.phms.shiro.CustomRolesAuthorizationFilter;
import org.apache.shiro.cache.MemoryConstrainedCacheManager;
import org.apache.shiro.mgt.SecurityManager;
import org.apache.shiro.session.mgt.SessionManager;
import org.apache.shiro.session.mgt.eis.MemorySessionDAO;
import org.apache.shiro.spring.LifecycleBeanPostProcessor;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.apache.shiro.web.session.mgt.DefaultWebSessionManager;
import org.springframework.aop.framework.autoproxy.DefaultAdvisorAutoProxyCreator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.servlet.Filter;
import java.util.LinkedHashMap;
import java.util.Map;


@Configuration
public class ShiroConfig {

	@Bean
	public static LifecycleBeanPostProcessor getLifecycleBeanPostProcessor() {
		return new LifecycleBeanPostProcessor();
	}


	@Bean
	public static DefaultAdvisorAutoProxyCreator getDefaultAdvisorAutoProxyCreator() {
		DefaultAdvisorAutoProxyCreator defaultAdvisorAutoProxyCreator = new DefaultAdvisorAutoProxyCreator();
		defaultAdvisorAutoProxyCreator.setUsePrefix(true);
		return defaultAdvisorAutoProxyCreator;
	}


	@Bean
	public ShiroFilterFactoryBean shirFilter(SecurityManager securityManager) {
		ShiroFilterFactoryBean shiroFilterFactoryBean = new ShiroFilterFactoryBean();
		shiroFilterFactoryBean.setSecurityManager(securityManager);


		Map<String, Filter> filtersMap = new LinkedHashMap<>();
		filtersMap.put("roleOrFilter", new CustomRolesAuthorizationFilter());
		shiroFilterFactoryBean.setFilters(filtersMap);


		shiroFilterFactoryBean.setLoginUrl("/");


		shiroFilterFactoryBean.setUnauthorizedUrl("/notRole");


		Map<String, String> filterChainDefinitionMap = new LinkedHashMap<>();

		filterChainDefinitionMap.put("/login", "anon");
		filterChainDefinitionMap.put("/index", "anon");
		filterChainDefinitionMap.put("/home", "anon");
		filterChainDefinitionMap.put("/open/**", "anon");
		filterChainDefinitionMap.put("/upload/**", "anon");
		filterChainDefinitionMap.put("/file/**", "anon");
		filterChainDefinitionMap.put("/regist", "anon");
		filterChainDefinitionMap.put("/doRegist", "anon");

		filterChainDefinitionMap.put("/css/**", "anon");
		filterChainDefinitionMap.put("/imgs/**", "anon");
		filterChainDefinitionMap.put("/js/**", "anon");
		filterChainDefinitionMap.put("/plug/**", "anon");
		filterChainDefinitionMap.put("/samples/**", "anon");

		filterChainDefinitionMap.put("/**", "anon");

		shiroFilterFactoryBean.setFilterChainDefinitionMap(filterChainDefinitionMap);
		return shiroFilterFactoryBean;
	}


	@Bean
	public DefaultWebSecurityManager securityManager(CustomRealm customRealm) {
		DefaultWebSecurityManager securityManager = new DefaultWebSecurityManager();

		securityManager.setRealm(customRealm);

		securityManager.setSessionManager(sessionManager());

		securityManager.setCacheManager(new MemoryConstrainedCacheManager());
		return securityManager;
	}


	@Bean
	public SessionManager sessionManager() {
		DefaultWebSessionManager shiroSessionManager = new DefaultWebSessionManager();
		shiroSessionManager.setSessionDAO(new MemorySessionDAO());
		shiroSessionManager.setSessionValidationSchedulerEnabled(false);
		return shiroSessionManager;
	}

}