package com.phms.model;

import java.util.HashMap;


public class LayuiMap extends HashMap<String, Object> {


	private static final long serialVersionUID = 1L;


	public LayuiMap success() {
		this.put("code", 0);
		this.put("src", "");
		return this;
	}


	public LayuiMap fail() {
		this.put("code", -1);
		return this;
	}


	public LayuiMap message(Object message) {
		this.put("message", message);
		return this;
	}


	public LayuiMap data(Object message) {
		this.put("data", message);
		return this;
	}

}
