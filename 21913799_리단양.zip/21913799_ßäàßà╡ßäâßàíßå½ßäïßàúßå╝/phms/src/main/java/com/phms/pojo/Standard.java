package com.phms.pojo;

public class Standard  extends BaseBean{

    private Long id;

    private Integer ageMin;

    private Integer ageMax;

    private Double tempMin;

    private Double tempMax;

    private Double weightMin;

    private Double weightMax;

    private Double heightMin;

    private Double heightMax;

    private Double appetiteMin;

    private Double appetiteMax;

    private String type;

    private Integer status;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getAgeMin() {
        return ageMin;
    }

    public void setAgeMin(Integer ageMin) {
        this.ageMin = ageMin;
    }

    public Integer getAgeMax() {
        return ageMax;
    }

    public void setAgeMax(Integer ageMax) {
        this.ageMax = ageMax;
    }

    public Double getTempMin() {
        return tempMin;
    }

    public void setTempMin(Double tempMin) {
        this.tempMin = tempMin;
    }

    public Double getTempMax() {
        return tempMax;
    }

    public void setTempMax(Double tempMax) {
        this.tempMax = tempMax;
    }


    public Double getWeightMin() {
        return weightMin;
    }


    public void setWeightMin(Double weightMin) {
        this.weightMin = weightMin;
    }

    public Double getWeightMax() {
        return weightMax;
    }

    public void setWeightMax(Double weightMax) {
        this.weightMax = weightMax;
    }

    public Double getHeightMin() {
        return heightMin;
    }

    public void setHeightMin(Double heightMin) {
        this.heightMin = heightMin;
    }

    public Double getHeightMax() {
        return heightMax;
    }

    public void setHeightMax(Double heightMax) {
        this.heightMax = heightMax;
    }


    public Double getAppetiteMin() {
        return appetiteMin;
    }

    public void setAppetiteMin(Double appetiteMin) {
        this.appetiteMin = appetiteMin;
    }


    public Double getAppetiteMax() {
        return appetiteMax;
    }


    public void setAppetiteMax(Double appetiteMax) {
        this.appetiteMax = appetiteMax;
    }


    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }


    public Integer getStatus() {
        return status;
    }


    public void setStatus(Integer status) {
        this.status = status;
    }
}