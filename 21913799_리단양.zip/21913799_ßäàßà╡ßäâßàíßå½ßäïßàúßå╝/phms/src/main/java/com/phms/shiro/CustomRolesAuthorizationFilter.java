/*
 * All rights Reserved, Copyright (C) Aisino LIMITED 2019
 * FileName: CustomRolesAuthorizationFilter.java
 */
package com.phms.shiro;

import org.apache.shiro.subject.Subject;
import org.apache.shiro.web.filter.authz.AuthorizationFilter;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;


public class CustomRolesAuthorizationFilter extends AuthorizationFilter {
	@Override
	protected boolean isAccessAllowed(ServletRequest req, ServletResponse resp, Object mappedValue) throws Exception {
		Subject subject = getSubject(req, resp);
		String[] perms = ((String[]) mappedValue);
		boolean isPermitted = true;
		if (null != perms && perms.length > 0) {
			if (perms.length == 1) {
				if (!isOneOfPermitted(perms[0], subject)) {
					isPermitted = false;
				}
			} else if (!isAllPermitted(perms, subject)) {
				isPermitted = false;
			}
		}
		return isPermitted;
	}


	private boolean isAllPermitted(String[] permStrArray, Subject subject) {
		boolean isPermitted = true;
		for (int index = 0, len = permStrArray.length; index < len; index++) {
			if (!isOneOfPermitted(permStrArray[index], subject)) {
				isPermitted = false;
				break;
			}
		}
		return isPermitted;
	}

	private boolean isOneOfPermitted(String permStr, Subject subject) {
		boolean isPermitted = false;
		String[] permArr = permStr.split("\\|");
		if (permArr.length > 0) {
			for (int index = 0, len = permArr.length; index < len; index++) {
				if (subject.hasRole(permArr[index])) {
					isPermitted = true;
					break;
				}
			}
		}
		return isPermitted;
	}
}
