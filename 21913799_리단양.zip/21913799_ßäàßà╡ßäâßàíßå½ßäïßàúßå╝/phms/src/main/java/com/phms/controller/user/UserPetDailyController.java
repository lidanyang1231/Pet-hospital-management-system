package com.phms.controller.user;

import com.phms.model.MMGridPageVoBean;
import com.phms.pojo.Pet;
import com.phms.pojo.PetDaily;
import com.phms.pojo.User;
import com.phms.service.PetDailyService;
import com.phms.service.PetService;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Date;
import java.util.List;


@Controller("UserPetDailyController")
@RequestMapping("/user/petDaily")
public class UserPetDailyController {
    @Autowired
    private PetDailyService petDailyService;
    @Autowired
    private PetService petService;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @RequestMapping("/petDailyListDoctor")
    public String petListDoctor(Long petId, Model model) {
        if (petId!=null){
            model.addAttribute("petId", petId);
        }else {
            model.addAttribute("petId", "petId");
        }
        return "user/petDailyListDoctor";
    }


    @RequestMapping("/petDailyList")
    public String petDailyList(Long petId, Model model) {
        if (petId!=null){
            model.addAttribute("petId", petId);
        }else {
            model.addAttribute("petId", "petId");
        }
        return "user/petDailyList";
    }

    @RequestMapping("/getAllByLimit")
    @ResponseBody
    public Object getAllByLimit(PetDaily pojo) {
        Subject subject = SecurityUtils.getSubject();
        User user = (User) subject.getPrincipal();
        pojo.setUserId(user.getId());
        return petDailyService.getAllByLimit(pojo);
    }


    @RequestMapping("/getAllByLimitDoctor")
    @ResponseBody
    public Object getAllByLimitDoctor(PetDaily pojo) {
        return petDailyService.getAllByLimit(pojo);
    }


    @RequestMapping(value = "/del")
    @ResponseBody
    @Transactional
    public String del(Long id) {
        try {
            petDailyService.deleteById(id);
            return "SUCCESS";
        } catch (Exception e) {
            logger.error("Delete exception", e);
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            return "ERROR";
        }
    }


    @RequestMapping(value = "/add")
    public String add(Model model) {
        Subject subject = SecurityUtils.getSubject();
        User user = (User) subject.getPrincipal();
        Pet pet = new Pet();
        pet.setUserId(user.getId());
        pet.setPage(1);
        pet.setLimit(100);
        MMGridPageVoBean<Pet> voBean = (MMGridPageVoBean<Pet>) petService.getAllByLimit(pet);
        List<Pet> rows = voBean.getRows();

        model.addAttribute("pets", rows);
        return "user/petDailyAdd";
    }


    @RequestMapping(value = "/doAdd")
    @ResponseBody
    @Transactional
    public String doAdd(PetDaily pojo) {
        Subject subject = SecurityUtils.getSubject();
        User user = (User) subject.getPrincipal();
        try {
            pojo.setUserId(user.getId());
            pojo.setCreateTime(new Date());
            petDailyService.add(pojo);
            return "SUCCESS";
        } catch (Exception e) {
            logger.error("Add exception", e);
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            return "ERROR";
        }
    }

}
