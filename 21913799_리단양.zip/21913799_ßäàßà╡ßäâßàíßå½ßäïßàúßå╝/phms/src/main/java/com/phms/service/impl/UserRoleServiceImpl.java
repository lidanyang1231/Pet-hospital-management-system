package com.phms.service.impl;

import com.phms.mapper.UserRoleMapper;
import com.phms.model.ResultMap;
import com.phms.pojo.User;
import com.phms.pojo.UserRole;
import com.phms.pojo.UserRoleExample;
import com.phms.service.UserRoleService;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import java.util.Collections;
import java.util.List;

@Service
public class UserRoleServiceImpl implements UserRoleService {

	@Autowired
	private UserRoleMapper userRoleMapper;

	private static final Logger logger = LoggerFactory.getLogger(UserRoleServiceImpl.class);


	@Override
	public List<UserRole> getRoleByUserId(String userId) {
		UserRoleExample example = new UserRoleExample();
		example.createCriteria().andUserIdEqualTo(userId);
		try {
			return userRoleMapper.selectByExample(example);
		} catch (Exception e) {
			logger.error("Description Obtaining permission based on user id is abnormal", e);
			return Collections.emptyList();
		}
	}


	@Override
	@Transactional
	public boolean delUserRoleByRoleId(int id) {
		UserRoleExample example = new UserRoleExample();
		example.createCriteria().andRoleIdEqualTo(id);
		try {
			userRoleMapper.deleteByExample(example);
			return true;
		} catch (Exception e) {
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			logger.error("Description Deleting a user permission table based on the permission id failed", e);
			return false;
		}
	}


	@Override
	@Transactional
	public ResultMap delUserRoleByUserIdAndRoleId(String userId, Integer roleId) {
		Subject subject = SecurityUtils.getSubject();
		User user = (User) subject.getPrincipal();

		if (userId.equals(user.getId())) {
			return new ResultMap().fail().message("DontOP");
		} else {
			UserRoleExample example = new UserRoleExample();
			example.createCriteria().andRoleIdEqualTo(roleId).andUserIdEqualTo(userId);
			try {
				userRoleMapper.deleteByExample(example);
				return new ResultMap().success().message("Successfully deleted");
			} catch (Exception e) {
				TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
				logger.error("Description Deleting a user permission table based on the user id permission id failed", e);
				return new ResultMap().fail().message("Deletion failure");
			}
		}
	}


	@Override
	@Transactional
	public String addUserRole(Integer roleId, String[] userIds) {
		try {
			if (null != roleId && userIds != null && userIds.length > 0) {
				for (String userId : userIds) {
					UserRole userRole = new UserRole();
					userRole.setRoleId(roleId);
					userRole.setUserId(userId);
					userRoleMapper.insert(userRole);
				}
			}
			return "SUCCESS";
		} catch (Exception e) {
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			logger.error("Description Failed to add a user role", e);
			return "ERROR";
		}
	}

	@Override
	public UserRole getUserRole(String userId) {
		UserRoleExample example = new UserRoleExample();
		example.createCriteria().andUserIdEqualTo(userId);
		return userRoleMapper.selectByExample(example).get(0);
	}
}
