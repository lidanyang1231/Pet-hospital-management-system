package com.phms.pojo;

import java.util.ArrayList;
import java.util.List;

public class StandardExample {

    protected String orderByClause;


    protected boolean distinct;


    protected List<Criteria> oredCriteria;

    public StandardExample() {
        oredCriteria = new ArrayList<Criteria>();
    }


    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }


    public String getOrderByClause() {
        return orderByClause;
    }


    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }


    public boolean isDistinct() {
        return distinct;
    }


    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }


    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }


    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }


    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }


    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }


    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }


    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Long value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Long value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Long value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Long value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Long value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Long value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Long> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Long> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Long value1, Long value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Long value1, Long value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andAgeMinIsNull() {
            addCriterion("age_min is null");
            return (Criteria) this;
        }

        public Criteria andAgeMinIsNotNull() {
            addCriterion("age_min is not null");
            return (Criteria) this;
        }

        public Criteria andAgeMinEqualTo(Integer value) {
            addCriterion("age_min =", value, "ageMin");
            return (Criteria) this;
        }

        public Criteria andAgeMinNotEqualTo(Integer value) {
            addCriterion("age_min <>", value, "ageMin");
            return (Criteria) this;
        }

        public Criteria andAgeMinGreaterThan(Integer value) {
            addCriterion("age_min >", value, "ageMin");
            return (Criteria) this;
        }

        public Criteria andAgeMinGreaterThanOrEqualTo(Integer value) {
            addCriterion("age_min >=", value, "ageMin");
            return (Criteria) this;
        }

        public Criteria andAgeMinLessThan(Integer value) {
            addCriterion("age_min <", value, "ageMin");
            return (Criteria) this;
        }

        public Criteria andAgeMinLessThanOrEqualTo(Integer value) {
            addCriterion("age_min <=", value, "ageMin");
            return (Criteria) this;
        }

        public Criteria andAgeMinIn(List<Integer> values) {
            addCriterion("age_min in", values, "ageMin");
            return (Criteria) this;
        }

        public Criteria andAgeMinNotIn(List<Integer> values) {
            addCriterion("age_min not in", values, "ageMin");
            return (Criteria) this;
        }

        public Criteria andAgeMinBetween(Integer value1, Integer value2) {
            addCriterion("age_min between", value1, value2, "ageMin");
            return (Criteria) this;
        }

        public Criteria andAgeMinNotBetween(Integer value1, Integer value2) {
            addCriterion("age_min not between", value1, value2, "ageMin");
            return (Criteria) this;
        }

        public Criteria andAgeMaxIsNull() {
            addCriterion("age_max is null");
            return (Criteria) this;
        }

        public Criteria andAgeMaxIsNotNull() {
            addCriterion("age_max is not null");
            return (Criteria) this;
        }

        public Criteria andAgeMaxEqualTo(Integer value) {
            addCriterion("age_max =", value, "ageMax");
            return (Criteria) this;
        }

        public Criteria andAgeMaxNotEqualTo(Integer value) {
            addCriterion("age_max <>", value, "ageMax");
            return (Criteria) this;
        }

        public Criteria andAgeMaxGreaterThan(Integer value) {
            addCriterion("age_max >", value, "ageMax");
            return (Criteria) this;
        }

        public Criteria andAgeMaxGreaterThanOrEqualTo(Integer value) {
            addCriterion("age_max >=", value, "ageMax");
            return (Criteria) this;
        }

        public Criteria andAgeMaxLessThan(Integer value) {
            addCriterion("age_max <", value, "ageMax");
            return (Criteria) this;
        }

        public Criteria andAgeMaxLessThanOrEqualTo(Integer value) {
            addCriterion("age_max <=", value, "ageMax");
            return (Criteria) this;
        }

        public Criteria andAgeMaxIn(List<Integer> values) {
            addCriterion("age_max in", values, "ageMax");
            return (Criteria) this;
        }

        public Criteria andAgeMaxNotIn(List<Integer> values) {
            addCriterion("age_max not in", values, "ageMax");
            return (Criteria) this;
        }

        public Criteria andAgeMaxBetween(Integer value1, Integer value2) {
            addCriterion("age_max between", value1, value2, "ageMax");
            return (Criteria) this;
        }

        public Criteria andAgeMaxNotBetween(Integer value1, Integer value2) {
            addCriterion("age_max not between", value1, value2, "ageMax");
            return (Criteria) this;
        }

        public Criteria andTempMinIsNull() {
            addCriterion("temp_min is null");
            return (Criteria) this;
        }

        public Criteria andTempMinIsNotNull() {
            addCriterion("temp_min is not null");
            return (Criteria) this;
        }

        public Criteria andTempMinEqualTo(Double value) {
            addCriterion("temp_min =", value, "tempMin");
            return (Criteria) this;
        }

        public Criteria andTempMinNotEqualTo(Double value) {
            addCriterion("temp_min <>", value, "tempMin");
            return (Criteria) this;
        }

        public Criteria andTempMinGreaterThan(Double value) {
            addCriterion("temp_min >", value, "tempMin");
            return (Criteria) this;
        }

        public Criteria andTempMinGreaterThanOrEqualTo(Double value) {
            addCriterion("temp_min >=", value, "tempMin");
            return (Criteria) this;
        }

        public Criteria andTempMinLessThan(Double value) {
            addCriterion("temp_min <", value, "tempMin");
            return (Criteria) this;
        }

        public Criteria andTempMinLessThanOrEqualTo(Double value) {
            addCriterion("temp_min <=", value, "tempMin");
            return (Criteria) this;
        }

        public Criteria andTempMinIn(List<Double> values) {
            addCriterion("temp_min in", values, "tempMin");
            return (Criteria) this;
        }

        public Criteria andTempMinNotIn(List<Double> values) {
            addCriterion("temp_min not in", values, "tempMin");
            return (Criteria) this;
        }

        public Criteria andTempMinBetween(Double value1, Double value2) {
            addCriterion("temp_min between", value1, value2, "tempMin");
            return (Criteria) this;
        }

        public Criteria andTempMinNotBetween(Double value1, Double value2) {
            addCriterion("temp_min not between", value1, value2, "tempMin");
            return (Criteria) this;
        }

        public Criteria andTempMaxIsNull() {
            addCriterion("temp_max is null");
            return (Criteria) this;
        }

        public Criteria andTempMaxIsNotNull() {
            addCriterion("temp_max is not null");
            return (Criteria) this;
        }

        public Criteria andTempMaxEqualTo(Double value) {
            addCriterion("temp_max =", value, "tempMax");
            return (Criteria) this;
        }

        public Criteria andTempMaxNotEqualTo(Double value) {
            addCriterion("temp_max <>", value, "tempMax");
            return (Criteria) this;
        }

        public Criteria andTempMaxGreaterThan(Double value) {
            addCriterion("temp_max >", value, "tempMax");
            return (Criteria) this;
        }

        public Criteria andTempMaxGreaterThanOrEqualTo(Double value) {
            addCriterion("temp_max >=", value, "tempMax");
            return (Criteria) this;
        }

        public Criteria andTempMaxLessThan(Double value) {
            addCriterion("temp_max <", value, "tempMax");
            return (Criteria) this;
        }

        public Criteria andTempMaxLessThanOrEqualTo(Double value) {
            addCriterion("temp_max <=", value, "tempMax");
            return (Criteria) this;
        }

        public Criteria andTempMaxIn(List<Double> values) {
            addCriterion("temp_max in", values, "tempMax");
            return (Criteria) this;
        }

        public Criteria andTempMaxNotIn(List<Double> values) {
            addCriterion("temp_max not in", values, "tempMax");
            return (Criteria) this;
        }

        public Criteria andTempMaxBetween(Double value1, Double value2) {
            addCriterion("temp_max between", value1, value2, "tempMax");
            return (Criteria) this;
        }

        public Criteria andTempMaxNotBetween(Double value1, Double value2) {
            addCriterion("temp_max not between", value1, value2, "tempMax");
            return (Criteria) this;
        }

        public Criteria andWeightMinIsNull() {
            addCriterion("weight_min is null");
            return (Criteria) this;
        }

        public Criteria andWeightMinIsNotNull() {
            addCriterion("weight_min is not null");
            return (Criteria) this;
        }

        public Criteria andWeightMinEqualTo(Double value) {
            addCriterion("weight_min =", value, "weightMin");
            return (Criteria) this;
        }

        public Criteria andWeightMinNotEqualTo(Double value) {
            addCriterion("weight_min <>", value, "weightMin");
            return (Criteria) this;
        }

        public Criteria andWeightMinGreaterThan(Double value) {
            addCriterion("weight_min >", value, "weightMin");
            return (Criteria) this;
        }

        public Criteria andWeightMinGreaterThanOrEqualTo(Double value) {
            addCriterion("weight_min >=", value, "weightMin");
            return (Criteria) this;
        }

        public Criteria andWeightMinLessThan(Double value) {
            addCriterion("weight_min <", value, "weightMin");
            return (Criteria) this;
        }

        public Criteria andWeightMinLessThanOrEqualTo(Double value) {
            addCriterion("weight_min <=", value, "weightMin");
            return (Criteria) this;
        }

        public Criteria andWeightMinIn(List<Double> values) {
            addCriterion("weight_min in", values, "weightMin");
            return (Criteria) this;
        }

        public Criteria andWeightMinNotIn(List<Double> values) {
            addCriterion("weight_min not in", values, "weightMin");
            return (Criteria) this;
        }

        public Criteria andWeightMinBetween(Double value1, Double value2) {
            addCriterion("weight_min between", value1, value2, "weightMin");
            return (Criteria) this;
        }

        public Criteria andWeightMinNotBetween(Double value1, Double value2) {
            addCriterion("weight_min not between", value1, value2, "weightMin");
            return (Criteria) this;
        }

        public Criteria andWeightMaxIsNull() {
            addCriterion("weight_max is null");
            return (Criteria) this;
        }

        public Criteria andWeightMaxIsNotNull() {
            addCriterion("weight_max is not null");
            return (Criteria) this;
        }

        public Criteria andWeightMaxEqualTo(Double value) {
            addCriterion("weight_max =", value, "weightMax");
            return (Criteria) this;
        }

        public Criteria andWeightMaxNotEqualTo(Double value) {
            addCriterion("weight_max <>", value, "weightMax");
            return (Criteria) this;
        }

        public Criteria andWeightMaxGreaterThan(Double value) {
            addCriterion("weight_max >", value, "weightMax");
            return (Criteria) this;
        }

        public Criteria andWeightMaxGreaterThanOrEqualTo(Double value) {
            addCriterion("weight_max >=", value, "weightMax");
            return (Criteria) this;
        }

        public Criteria andWeightMaxLessThan(Double value) {
            addCriterion("weight_max <", value, "weightMax");
            return (Criteria) this;
        }

        public Criteria andWeightMaxLessThanOrEqualTo(Double value) {
            addCriterion("weight_max <=", value, "weightMax");
            return (Criteria) this;
        }

        public Criteria andWeightMaxIn(List<Double> values) {
            addCriterion("weight_max in", values, "weightMax");
            return (Criteria) this;
        }

        public Criteria andWeightMaxNotIn(List<Double> values) {
            addCriterion("weight_max not in", values, "weightMax");
            return (Criteria) this;
        }

        public Criteria andWeightMaxBetween(Double value1, Double value2) {
            addCriterion("weight_max between", value1, value2, "weightMax");
            return (Criteria) this;
        }

        public Criteria andWeightMaxNotBetween(Double value1, Double value2) {
            addCriterion("weight_max not between", value1, value2, "weightMax");
            return (Criteria) this;
        }

        public Criteria andHeightMinIsNull() {
            addCriterion("height_min is null");
            return (Criteria) this;
        }

        public Criteria andHeightMinIsNotNull() {
            addCriterion("height_min is not null");
            return (Criteria) this;
        }

        public Criteria andHeightMinEqualTo(Double value) {
            addCriterion("height_min =", value, "heightMin");
            return (Criteria) this;
        }

        public Criteria andHeightMinNotEqualTo(Double value) {
            addCriterion("height_min <>", value, "heightMin");
            return (Criteria) this;
        }

        public Criteria andHeightMinGreaterThan(Double value) {
            addCriterion("height_min >", value, "heightMin");
            return (Criteria) this;
        }

        public Criteria andHeightMinGreaterThanOrEqualTo(Double value) {
            addCriterion("height_min >=", value, "heightMin");
            return (Criteria) this;
        }

        public Criteria andHeightMinLessThan(Double value) {
            addCriterion("height_min <", value, "heightMin");
            return (Criteria) this;
        }

        public Criteria andHeightMinLessThanOrEqualTo(Double value) {
            addCriterion("height_min <=", value, "heightMin");
            return (Criteria) this;
        }

        public Criteria andHeightMinIn(List<Double> values) {
            addCriterion("height_min in", values, "heightMin");
            return (Criteria) this;
        }

        public Criteria andHeightMinNotIn(List<Double> values) {
            addCriterion("height_min not in", values, "heightMin");
            return (Criteria) this;
        }

        public Criteria andHeightMinBetween(Double value1, Double value2) {
            addCriterion("height_min between", value1, value2, "heightMin");
            return (Criteria) this;
        }

        public Criteria andHeightMinNotBetween(Double value1, Double value2) {
            addCriterion("height_min not between", value1, value2, "heightMin");
            return (Criteria) this;
        }

        public Criteria andHeightMaxIsNull() {
            addCriterion("height_max is null");
            return (Criteria) this;
        }

        public Criteria andHeightMaxIsNotNull() {
            addCriterion("height_max is not null");
            return (Criteria) this;
        }

        public Criteria andHeightMaxEqualTo(Double value) {
            addCriterion("height_max =", value, "heightMax");
            return (Criteria) this;
        }

        public Criteria andHeightMaxNotEqualTo(Double value) {
            addCriterion("height_max <>", value, "heightMax");
            return (Criteria) this;
        }

        public Criteria andHeightMaxGreaterThan(Double value) {
            addCriterion("height_max >", value, "heightMax");
            return (Criteria) this;
        }

        public Criteria andHeightMaxGreaterThanOrEqualTo(Double value) {
            addCriterion("height_max >=", value, "heightMax");
            return (Criteria) this;
        }

        public Criteria andHeightMaxLessThan(Double value) {
            addCriterion("height_max <", value, "heightMax");
            return (Criteria) this;
        }

        public Criteria andHeightMaxLessThanOrEqualTo(Double value) {
            addCriterion("height_max <=", value, "heightMax");
            return (Criteria) this;
        }

        public Criteria andHeightMaxIn(List<Double> values) {
            addCriterion("height_max in", values, "heightMax");
            return (Criteria) this;
        }

        public Criteria andHeightMaxNotIn(List<Double> values) {
            addCriterion("height_max not in", values, "heightMax");
            return (Criteria) this;
        }

        public Criteria andHeightMaxBetween(Double value1, Double value2) {
            addCriterion("height_max between", value1, value2, "heightMax");
            return (Criteria) this;
        }

        public Criteria andHeightMaxNotBetween(Double value1, Double value2) {
            addCriterion("height_max not between", value1, value2, "heightMax");
            return (Criteria) this;
        }

        public Criteria andAppetiteMinIsNull() {
            addCriterion("appetite_min is null");
            return (Criteria) this;
        }

        public Criteria andAppetiteMinIsNotNull() {
            addCriterion("appetite_min is not null");
            return (Criteria) this;
        }

        public Criteria andAppetiteMinEqualTo(Double value) {
            addCriterion("appetite_min =", value, "appetiteMin");
            return (Criteria) this;
        }

        public Criteria andAppetiteMinNotEqualTo(Double value) {
            addCriterion("appetite_min <>", value, "appetiteMin");
            return (Criteria) this;
        }

        public Criteria andAppetiteMinGreaterThan(Double value) {
            addCriterion("appetite_min >", value, "appetiteMin");
            return (Criteria) this;
        }

        public Criteria andAppetiteMinGreaterThanOrEqualTo(Double value) {
            addCriterion("appetite_min >=", value, "appetiteMin");
            return (Criteria) this;
        }

        public Criteria andAppetiteMinLessThan(Double value) {
            addCriterion("appetite_min <", value, "appetiteMin");
            return (Criteria) this;
        }

        public Criteria andAppetiteMinLessThanOrEqualTo(Double value) {
            addCriterion("appetite_min <=", value, "appetiteMin");
            return (Criteria) this;
        }

        public Criteria andAppetiteMinIn(List<Double> values) {
            addCriterion("appetite_min in", values, "appetiteMin");
            return (Criteria) this;
        }

        public Criteria andAppetiteMinNotIn(List<Double> values) {
            addCriterion("appetite_min not in", values, "appetiteMin");
            return (Criteria) this;
        }

        public Criteria andAppetiteMinBetween(Double value1, Double value2) {
            addCriterion("appetite_min between", value1, value2, "appetiteMin");
            return (Criteria) this;
        }

        public Criteria andAppetiteMinNotBetween(Double value1, Double value2) {
            addCriterion("appetite_min not between", value1, value2, "appetiteMin");
            return (Criteria) this;
        }

        public Criteria andAppetiteMaxIsNull() {
            addCriterion("appetite_max is null");
            return (Criteria) this;
        }

        public Criteria andAppetiteMaxIsNotNull() {
            addCriterion("appetite_max is not null");
            return (Criteria) this;
        }

        public Criteria andAppetiteMaxEqualTo(Double value) {
            addCriterion("appetite_max =", value, "appetiteMax");
            return (Criteria) this;
        }

        public Criteria andAppetiteMaxNotEqualTo(Double value) {
            addCriterion("appetite_max <>", value, "appetiteMax");
            return (Criteria) this;
        }

        public Criteria andAppetiteMaxGreaterThan(Double value) {
            addCriterion("appetite_max >", value, "appetiteMax");
            return (Criteria) this;
        }

        public Criteria andAppetiteMaxGreaterThanOrEqualTo(Double value) {
            addCriterion("appetite_max >=", value, "appetiteMax");
            return (Criteria) this;
        }

        public Criteria andAppetiteMaxLessThan(Double value) {
            addCriterion("appetite_max <", value, "appetiteMax");
            return (Criteria) this;
        }

        public Criteria andAppetiteMaxLessThanOrEqualTo(Double value) {
            addCriterion("appetite_max <=", value, "appetiteMax");
            return (Criteria) this;
        }

        public Criteria andAppetiteMaxIn(List<Double> values) {
            addCriterion("appetite_max in", values, "appetiteMax");
            return (Criteria) this;
        }

        public Criteria andAppetiteMaxNotIn(List<Double> values) {
            addCriterion("appetite_max not in", values, "appetiteMax");
            return (Criteria) this;
        }

        public Criteria andAppetiteMaxBetween(Double value1, Double value2) {
            addCriterion("appetite_max between", value1, value2, "appetiteMax");
            return (Criteria) this;
        }

        public Criteria andAppetiteMaxNotBetween(Double value1, Double value2) {
            addCriterion("appetite_max not between", value1, value2, "appetiteMax");
            return (Criteria) this;
        }

        public Criteria andTypeIsNull() {
            addCriterion("type is null");
            return (Criteria) this;
        }

        public Criteria andTypeIsNotNull() {
            addCriterion("type is not null");
            return (Criteria) this;
        }

        public Criteria andTypeEqualTo(String value) {
            addCriterion("type =", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotEqualTo(String value) {
            addCriterion("type <>", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeGreaterThan(String value) {
            addCriterion("type >", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeGreaterThanOrEqualTo(String value) {
            addCriterion("type >=", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeLessThan(String value) {
            addCriterion("type <", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeLessThanOrEqualTo(String value) {
            addCriterion("type <=", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeLike(String value) {
            addCriterion("type like", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotLike(String value) {
            addCriterion("type not like", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeIn(List<String> values) {
            addCriterion("type in", values, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotIn(List<String> values) {
            addCriterion("type not in", values, "type");
            return (Criteria) this;
        }

        public Criteria andTypeBetween(String value1, String value2) {
            addCriterion("type between", value1, value2, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotBetween(String value1, String value2) {
            addCriterion("type not between", value1, value2, "type");
            return (Criteria) this;
        }

        public Criteria andStatusIsNull() {
            addCriterion("status is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("status is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(Integer value) {
            addCriterion("status =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(Integer value) {
            addCriterion("status <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(Integer value) {
            addCriterion("status >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("status >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(Integer value) {
            addCriterion("status <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(Integer value) {
            addCriterion("status <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<Integer> values) {
            addCriterion("status in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<Integer> values) {
            addCriterion("status not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(Integer value1, Integer value2) {
            addCriterion("status between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("status not between", value1, value2, "status");
            return (Criteria) this;
        }
    }


    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }


    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}