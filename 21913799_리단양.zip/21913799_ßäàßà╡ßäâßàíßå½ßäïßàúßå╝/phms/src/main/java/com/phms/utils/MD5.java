package com.phms.utils;

import org.springframework.util.DigestUtils;


public class MD5 {
	private MD5() {
		throw new IllegalStateException("MD5 Utility class");
	}


	public static String md5(String text) {

		return DigestUtils.md5DigestAsHex(text.getBytes());
	}


	public static boolean verify(String text, String md5) {

		String md5Text = md5(text);
		return md5Text.equals(md5);
	}
}
