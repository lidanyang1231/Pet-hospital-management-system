package com.phms.service.impl;

import com.phms.mapper.PageMapper;
import com.phms.model.ResultMap;
import com.phms.pojo.Page;
import com.phms.pojo.PageExample;
import com.phms.service.PageService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import java.util.Collections;
import java.util.List;

@Service
public class PageServiceImpl implements PageService {
	@Autowired
	private PageMapper pageMapper;

	private static final Logger logger = LoggerFactory.getLogger(PageServiceImpl.class);


	@Override
	@Transactional
	public List<Page> getAllPageByRoleId(Integer roleId) {
		try {
			return pageMapper.getAllPageByRoleId(roleId);
		} catch (Exception e) {
			logger.error("All pages of the role cannot be queried", e);
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return Collections.emptyList();
		}
	}


	@Override
	@Transactional
	public List<Page> getAllPage() {
		try {
			return pageMapper.getAllPage();
		} catch (Exception e) {
			logger.error("Get all page exceptions", e);
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return Collections.emptyList();
		}
	}


	@Override
	@Transactional
	public ResultMap updatePageById(Page page) {
		ResultMap map = new ResultMap();
		try {
			PageExample example = new PageExample();
			example.createCriteria().andPageIdEqualTo(page.getPageId());
			pageMapper.updateByExampleSelective(page, example);
			map.success().message("Page modified successfully!");
		} catch (Exception e) {
			logger.error("Page modification exception", e);
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			map.fail().message("Page modification failed");
		}

		return map;
	}


	@Override
	public Page addPage(Page page) {
		ResultMap map = new ResultMap();
		try {
			pageMapper.insert(page);
			map.success().message("Page added successfully!");
		} catch (Exception e) {
			logger.error("Page addition exception", e);
			map.fail().message("Page addition failure");
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return page;
	}


	@Override
	public ResultMap delPageById(Integer id) {
		Page page = new Page();
		page.setDeleteFlag(1);
		PageExample example = new PageExample();
		example.createCriteria().andPageIdEqualTo(id);
		ResultMap map = new ResultMap();

		try {
			pageMapper.deleteByPrimaryKey(id);
			pageMapper.updateByExampleSelective(page, example);
			map.success().message("Page deleted successfully!");
		} catch (Exception e) {
			logger.error("Page deletion exception", e);
			map.fail().message("Page deletion failure");
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		return map;
	}


	@Override
	public List<Page> getAllRolePageByUserId(String userId) {
		try {
			return pageMapper.getAllRolePageByUserId(userId);
		} catch (Exception e) {
			logger.error("Description Failed to obtain the page based on the user id", e);
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return Collections.emptyList();
		}
	}

}
