package com.phms.filter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.*;
import java.io.IOException;



public class TimeFilter implements Filter {


	private final Logger logger = LoggerFactory.getLogger(TimeFilter.class);


	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		logger.info("=======Initialization filter=========");
	}


	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain)
			throws IOException, ServletException {

		filterChain.doFilter(request,  	response);

	}


	@Override
	public void destroy() {
		logger.info("=======Destruction filter=========");
	}
}
