package com.phms.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;


public class ListenerTest implements ServletContextListener {

	private final Logger logger = LoggerFactory.getLogger(ListenerTest.class);


	@Override
	public void contextInitialized(ServletContextEvent sce) {
		logger.info("-------Listener initialization-------");
	}


	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		logger.info("-------Destroy monitor-------");
	}
}
