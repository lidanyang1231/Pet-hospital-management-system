package com.phms.controller.admin;

import com.phms.model.ResultMap;
import com.phms.pojo.Page;
import com.phms.pojo.Role;
import com.phms.pojo.User;
import com.phms.pojo.UserParameter;
import com.phms.service.*;
import com.phms.utils.MD5;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Date;
import java.util.List;


@Controller("Admin")
@RequestMapping("/admin")
public class Adminontroller {

	@Autowired
	private PageService pageService;
	@Autowired
	private RoleService roleService;
	@Autowired
	private PageRoleService pageRoleService;
	@Autowired
	private UserRoleService userRoleService;
	@Autowired
	private UserService userService;

	private final Logger logger = LoggerFactory.getLogger(Adminontroller.class);


	@RequestMapping("/page")
	public String page(Model model) {
		List<Page> pageList = pageService.getAllPage();
		model.addAttribute("pageList", pageList);
		return "sa/page";
	}


	@RequestMapping("/role")
	public String role(Model model) {
		return "sa/role";
	}


	@RequestMapping("/getAllRole")
	@ResponseBody
	public List<Role> getAllRole() {
		return roleService.getAllRole();
	}


	@RequestMapping("/getAllPage")
	@ResponseBody
	public List<Page> getAllPage() {
		return pageService.getAllPage();
	}


	@RequestMapping("/getPageByRole")
	@ResponseBody
	public Object getPageByRole(Integer roleId) {
		return pageService.getAllPageByRoleId(roleId);
	}


	@RequestMapping("/updatePageById")
	@ResponseBody
	public ResultMap updatePageById(Page page) {
		return pageService.updatePageById(page);
	}


	@RequestMapping("/addPage")
	@ResponseBody
	public Page addPage(Page page) {
		return pageService.addPage(page);
	}


	@RequestMapping("/delPageById")
	@ResponseBody
	public ResultMap delPageById(Integer id) {
		if (null == id) {
			return new ResultMap().fail().message("参数错误");
		}
		return pageService.delPageById(id);
	}


	@RequestMapping("/addRole")
	@ResponseBody
	public String addRole(String name) {
		return roleService.addRole(name);
	}


	@RequestMapping("/delRole")
	@ResponseBody
	public String delRole(int id) {

		boolean flag1 = roleService.delRoleById(id);

		boolean flag2 = pageRoleService.delPageRoleByRoleId(id);

		boolean flag3 = userRoleService.delUserRoleByRoleId(id);

		if (flag1 && flag2 && flag3) {
			return "SUCCESS";
		}
		return "ERROR";
	}


	@RequestMapping("/updateRole")
	@ResponseBody
	public String updateRole(Integer id, String name) {
		int n = roleService.updateRoleById(id, name);
		if (n != 0) {
			return "SUCCESS";
		}
		return "ERROR";
	}


	@RequestMapping("/addPageRoleByRoleId")
	@ResponseBody
	public String addPageRoleByRoleId(Integer roleId, Integer[] pageIds) {

		if (null == roleId) {
			return "ERROR";
		}


		boolean flag1 = pageRoleService.delPageRoleByRoleId(roleId);
		boolean flag2 = pageRoleService.addPageRoles(roleId, pageIds);

		if (flag1 && flag2) {
			return "SUCCESS";
		}
		return "ERROR";
	}


	@RequestMapping("/getAllUserByRoleId")
	@ResponseBody
	public Object getAllUserByRoleId(Integer roleId, String roleNot, Integer page, Integer limit) {
		if (null == roleNot) {
			return userService.getAllUserByRoleId(roleId, page, limit);
		}
		return userService.getAllUserByNotRoleId(roleId, page, limit);
	}


	@RequestMapping("/delUserRoleByUserIdAndRoleId")
	@ResponseBody
	public ResultMap delUserRoleByUserIdAndRoleId(String userId, Integer roleId) {
		return userRoleService.delUserRoleByUserIdAndRoleId(userId, roleId);
	}


	@RequestMapping("/selectUserRole")
	public String selectUserRole() {
		return "sa/selectUserRole";
	}


	@RequestMapping("/addUserRole")
	@ResponseBody
	public String addUserRole(Integer roleId, String[] userIds) {
		return userRoleService.addUserRole(roleId, userIds);
	}


	@RequestMapping(value = "/userAddPage")
	public String userAddPage() {
		return "sa/userAdd";
	}


	@RequestMapping(value = "/userPage")
	public String userPage() {
		return "sa/userList";
	}


	@RequestMapping("/getAllUserByLimit")
	@ResponseBody
	public Object getAllUserByLimit(UserParameter userParameter) {
		return userService.getAllUserByLimit(userParameter);
	}


	@RequestMapping("/getAllDelUserByLimit")
	@ResponseBody
	public Object getAllDelUserByLimit(UserParameter userParameter) {
		return userService.getAllDelUserByLimit(userParameter);
	}


	@RequestMapping(value = "delUser")
	@ResponseBody
	@Transactional
	public String delUser(Long[] ids) {
		Subject subject = SecurityUtils.getSubject();
		User user = (User) subject.getPrincipal();
		try {
			for (Long id : ids) {
				if (id.equals(user.getId())) {
					return "DontOP";
				}
				userService.delUserById(id);
			}
			return "SUCCESS";
		} catch (Exception e) {
			logger.error("Updating a user based on the user id is abnormal", e);
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return "ERROR";
		}
	}


	@RequestMapping(value = "/addUserPage")
	public String addUserPage(Long userId, Model model) {
		model.addAttribute("manageUser", userId);
		if (null != userId) {
			User user = userService.selectByPrimaryKey(userId);
			model.addAttribute("manageUser", user);
		}
		return "sa/userAdd";
	}


	@ResponseBody
	@RequestMapping("/checkUserId")
	public User checkUserId(Long userId) {
		return userService.selectByPrimaryKey(userId);
	}


	@ResponseBody
	@RequestMapping("/addUser")
	public String addUser(User user) {
		try {
			user.setPassword(MD5.md5(user.getPassword()));
			user.setCreateTime(new Date());
			userService.addUser(user);

			User u = userService.getUserByPhoneAndName(user.getPhone(), user.getName());

			String[] ids = new String[1];
			ids[0] = u.getId()+"";

			userRoleService.addUserRole(3, ids);
			return "SUCCESS";
		} catch (Exception e) {
			return "ERR";
		}
	}


	@ResponseBody
	@RequestMapping("/updateUser")
	public String updateUser(User user, Long oldId) {
		return userService.updateUser(oldId, user);
	}


	@RequestMapping("/delUserPage")
	public String delUserPage() {
		return "sa/userDelPage";
	}
}
