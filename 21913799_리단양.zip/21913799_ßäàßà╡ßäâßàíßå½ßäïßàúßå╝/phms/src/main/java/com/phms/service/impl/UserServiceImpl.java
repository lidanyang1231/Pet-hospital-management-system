package com.phms.service.impl;

import com.phms.mapper.UserMapper;
import com.phms.mapper.UserRoleMapper;
import com.phms.model.MMGridPageVoBean;
import com.phms.model.ResultMap;
import com.phms.pojo.*;
import com.phms.service.UserService;
import com.phms.utils.MD5;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserMapper userMapper;
	@Autowired
	private ResultMap resultMap;
	@Autowired
	private UserRoleMapper userRoleMapper;
	private final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);


	@Override
	public ResultMap login(String username, String password) {

		Subject subject = SecurityUtils.getSubject();

		UsernamePasswordToken token = new UsernamePasswordToken(username, MD5.md5(password));

		try {
			subject.login(token);
		}catch (Exception e) {
			return resultMap.fail().message(e.getMessage());
		}
		User user = (User) subject.getPrincipal();

		List<String> role = userRoleMapper.getRoles(user.getId()+"");
		if (!role.isEmpty()) {
			logger.info("Welcome to ------. Your permission is {}", role);
			return resultMap.success().message("Welcome aboard");
		}
		return resultMap.fail().message("Permission error！");
	}


	@Override
	public boolean checkUserPassword(String password) {
		Subject subject = SecurityUtils.getSubject();
		User user = (User) subject.getPrincipal();

		if (null != user) {
			String pass = user.getPassword();
			if (pass != null && pass.equals(MD5.md5(password))) {
				return true;
			}
		}
		return false;
	}


	@Override
	@Transactional
	public String updatePassword(String password) {
		Subject subject = SecurityUtils.getSubject();
		User user = (User) subject.getPrincipal();
		int n = 0;

		if (null != user) {
			User upUser = new User();
			upUser.setPassword(MD5.md5(password));
			UserExample userExample = new UserExample();
			try {
				userExample.createCriteria().andIdEqualTo(user.getId());
				n = userMapper.updateByExampleSelective(upUser, userExample);
			} catch (Exception e) {
				logger.error("Password change exception", e);

				TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
				return "ERROR";
			}
		}
		if (n != 0) {
			return "SUCCESS";
		}
		return "ERROR";
	}


	@Override
	public User selectUserByUserId(Long userId) {
		try {
			return userMapper.selectByPrimaryKey(userId);
		} catch (Exception e) {
			logger.error("Description Querying user information based on the user id fails", e);
			return null;
		}
	}


	@Override
	public Object getAllUserByRoleId(Integer roleId, Integer page, Integer limit) {
		int size = userMapper.countAllUserByRoleId(roleId);

		Integer begin = (page - 1) * limit;
		Integer count = limit;

		List<User> rows = new ArrayList<>();
		try {
			rows = userMapper.getAllUserByRoleId(roleId, begin, count);
		} catch (Exception e) {
			logger.error("Obtain all users under the permission according to the permission id exception", e);
		}

		MMGridPageVoBean<User> vo = new MMGridPageVoBean<>();
		vo.setTotal(size);
		vo.setRows(rows);

		return vo;
	}


	@Override
	public Object getAllUserByNotRoleId(Integer roleId, Integer page, Integer limit) {
		int size = userMapper.countAllUserByNotRoleId(roleId);

		Integer begin = (page - 1) * limit;
		Integer count = limit;

		List<User> rows = new ArrayList<>();
		try {
			rows = userMapper.getAllUserByNotRoleId(roleId, begin, count);
		} catch (Exception e) {
			logger.error("Get exception for all users not with this permission according to the permission id", e);
		}

		MMGridPageVoBean<User> vo = new MMGridPageVoBean<>();
		vo.setTotal(size);
		vo.setRows(rows);

		return vo;
	}


	@Override
	public User selectByPrimaryKey(Long userId) {
		return userMapper.selectByPrimaryKey(userId);
	}

	@Override
	public List<User> getAdmins() {
		List<User> list = new ArrayList<User>();
		UserRoleExample example = new UserRoleExample();
		example.createCriteria().andRoleIdEqualTo(1);
		List<UserRole> userRoles = userRoleMapper.selectByExample(example);
		for (UserRole userRole : userRoles) {
			User user = userMapper.selectByPrimaryKey(Long.parseLong(userRole.getUserId()));
			list.add(user);
		}
		return list;
	}


	@Override
	public Object getAllUserByLimit(UserParameter userParameter) {
		int size = 0;

		Integer begin = (userParameter.getPage() - 1) * userParameter.getLimit();
		userParameter.setPage(begin);

		List<User> rows = new ArrayList<>();
		try {
			rows = userMapper.getAllUserByLimit(userParameter);
			size = userMapper.countAllUserByLimit(userParameter);
		} catch (Exception e) {
			logger.error("An exception occurs when users are queried based on criteria", e);
		}
		MMGridPageVoBean<User> vo = new MMGridPageVoBean<>();
		vo.setTotal(size);
		vo.setRows(rows);

		return vo;
	}


	@Override
	@Transactional
	public void delUserById(Long id) {
		try {

			User user = new User();
			UserExample userExample = new UserExample();
			userExample.createCriteria().andIdEqualTo(id);


			UserRoleExample userRoleExample = new UserRoleExample();
			userRoleExample.createCriteria().andUserIdEqualTo(id+"");
			userMapper.deleteByExample(userExample);
			userRoleMapper.deleteByExample(userRoleExample);
		} catch (Exception e) {
			logger.error("An exception occurred when deleting a user", e);
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
	}


	@Override
	public void addUser(User user) throws Exception {
		userMapper.insert(user);
	}


	@Override
	@Transactional
	public String updateUser(User user) {
		try {
			String pass = user.getPassword();
			if (pass != null && !pass.equals("")) {
				user.setPassword(MD5.md5(pass));
			}
			userMapper.updateByPrimaryKeySelective(user);
			return "SUCCESS";
		} catch (Exception e) {
			logger.error("Updating a user based on the user id is abnormal", e);
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return "ERR";
		}
	}

	@Override
	public List<User> getAllUser() {
		List<User> list = new ArrayList<User>();
		UserRoleExample example = new UserRoleExample();
		example.createCriteria().andRoleIdNotEqualTo(4);
		List<UserRole> userRoles = userRoleMapper.selectByExample(example);
		for (UserRole userRole : userRoles) {
			User user = userMapper.selectByPrimaryKey(Long.parseLong(userRole.getUserId()));
			list.add(user);
		}
		return list;
	}


	@Override
	public User getAdminById(Long userId) {
		return userMapper.selectByPrimaryKey(userId);
	}

	@Override
	public Object getAllDelUserByLimit(UserParameter userParameter) {
		int size = 0;

		Integer begin = (userParameter.getPage() - 1) * userParameter.getLimit();
		userParameter.setPage(begin);

		List<User> rows = new ArrayList<>();
		try {
			rows = userMapper.getAllDelUserByLimit(userParameter);
			size = userMapper.countAllDelUserByLimit(userParameter);
		} catch (Exception e) {
			logger.error("An exception occurs when users are queried based on criteria", e);
		}
		MMGridPageVoBean<User> vo = new MMGridPageVoBean<>();
		vo.setTotal(size);
		vo.setRows(rows);

		return vo;
	}



	@Override
	public String updateUser(Long oldId, User user) {
		UserExample example = new UserExample();
		example.createCriteria().andIdEqualTo(oldId);
		try {
			String pass = user.getPassword();
			boolean xgpass = false;
			User oldUser = userMapper.selectByPrimaryKey(oldId);
			if (pass != null && !pass.equals("")) {
				user.setPassword(MD5.md5(pass));
				xgpass = true;
			} else {
				user.setPassword(oldUser.getPassword());
			}
			user.setCreateTime(oldUser.getCreateTime());


			UserRoleExample userRoleExample = new UserRoleExample();
			userRoleExample.createCriteria().andUserIdEqualTo(oldId+"");
			List<UserRole> olds = userRoleMapper.selectByExample(userRoleExample);
			for (UserRole userRole : olds) {
				userRole.setUserId(user.getId()+"");
				userRoleMapper.updateByExampleSelective(userRole, userRoleExample);
			}
			userMapper.updateByExample(user, example);


			Subject subject = SecurityUtils.getSubject();
			User ad = (User) subject.getPrincipal();

			if (!oldId.equals(user.getId()) && oldId.equals(ad.getId())) {
				return "LGINOUT";
			} else if (oldId.equals(ad.getId()) && xgpass) {
				return "LGINOUT";
			}
			return "SUCCESS";
		} catch (Exception e) {
			logger.error("Updating a user based on the user id is abnormal", e);
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			return "ERR";
		}
	}

	@Override
	public List<User> selectAllUser() {
		
		return userMapper.selectAllUser();
	}

	@Override
	public User getUserByPhoneAndName(String phone, String name) {
		return userMapper.getUserByPhoneAndName(phone, name);
	}

	@Override
	public void save(User user) {
		userMapper.insert(user);
	}

	@Override
	public User getByIdCard(String idCard) {
		return userMapper.selectByIdCard(idCard);
	}

	@Override
	public List<User> listDoctor() {
		UserExample example = new UserExample();
		example.createCriteria().andDepartmentIsNotNull();
		return userMapper.selectByExample(example);
	}
}
