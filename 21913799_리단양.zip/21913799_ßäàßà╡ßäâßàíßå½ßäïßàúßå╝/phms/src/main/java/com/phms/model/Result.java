package com.phms.model;


import java.io.Serializable;
import java.util.List;

public class Result<T> implements Serializable {


	private static final long serialVersionUID = 1L;

	private int page;
	private int limit;
	private int count;
	private String code;
	private String msg;
	private List<T> data;
	private T example;

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public List<T> getData() {
		return data;
	}

	public void setData(List<T> data) {
		this.data = data;
	}

	public T getExample() {
		return example;
	}

	public void setExample(T example) {
		this.example = example;
	}

	public Result(int page, int limit, int count, String code, String msg, List<T> data, T example) {
		this.page = page;
		this.limit = limit;
		this.count = count;
		this.code = code;
		this.msg = msg;
		this.data = data;
		this.example = example;
	}

	public Result() {
	}

	@Override
	public String toString() {
		return "Result [page=" + page + ", limit=" + limit + ", count=" + count + ", code=" + code + ", msg=" + msg
				+ ", data=" + data + ", example=" + example + "]";
	}

}
