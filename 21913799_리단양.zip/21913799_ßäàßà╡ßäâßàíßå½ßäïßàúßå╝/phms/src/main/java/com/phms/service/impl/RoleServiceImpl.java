package com.phms.service.impl;


import com.phms.mapper.RoleMapper;
import com.phms.pojo.Role;
import com.phms.pojo.RoleExample;
import com.phms.service.RoleService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import java.util.Collections;
import java.util.List;

@Service
public class RoleServiceImpl implements RoleService {
	@Autowired
	private RoleMapper roleMapper;
	private static final Logger logger = LoggerFactory.getLogger(RoleServiceImpl.class);


	@Override
	public List<Role> getAllRole() {
		RoleExample example = new RoleExample();
		example.createCriteria().andRoleIdIsNotNull();
		try {
			return roleMapper.selectByExample(example);
		} catch (Exception e) {
			logger.error("Obtain all role exceptions", e);
			return Collections.emptyList();
		}
	}


	@Override
	@Transactional
	public String addRole(String name) {
		Role record = new Role();
		record.setName(name);
		try {
			roleMapper.insert(record);
			return "SUCCESS";
		} catch (Exception e) {
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			logger.error("Add role exception", e);
			return "ERROR";
		}
	}


	@Override
	@Transactional
	public boolean delRoleById(Integer id) {
		try {
			roleMapper.deleteByPrimaryKey(id);
			return true;
		} catch (Exception e) {
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			logger.error("Description Deleting permissions based on permissions id is abnormal", e);
			return false;
		}
	}


	@Override
	@Transactional
	public int updateRoleById(Integer id, String name) {
		Role record = new Role();
		record.setName(name);

		RoleExample example = new RoleExample();

		example.createCriteria().andRoleIdEqualTo(id);

		try {
			roleMapper.updateByExampleSelective(record, example);
			return 1;
		} catch (Exception e) {
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			logger.error("Description Updating permissions based on permissions id is abnormal", e);
			return 0;
		}
	}
}